function setup() {
  createCanvas(400, 400);
  money = 0
  auto = 0
  cost = 10 //slaves
  cost1 = 8 //farm power
  cost2 = 20 //slave power
  cost3 = 100 //hut
  power = 1
  power1 = 1
  day = 1
  month = 1
  year = 1780
  millisecond = 0
  second = 0
  huts = 0 
  clicks = 0
  dialogue = " "
  timer = 0
  achievements = 0
}

mouseClicked = function() {
  clicks += 1
  if (mouseX >= 20 && mouseX <= 175 &&
    mouseY >= 175 && mouseY <= 225) {
    if (money >= cost1) {
      money -= cost1
      power += 1
      cost1 += power
    }
  }

  if (mouseX >= 175 && mouseX <= 225 &&
    mouseY >= 175 && mouseY <= 225) {
    money += power
  }

  if (mouseX >= 325 && mouseX <= 375 &&
    mouseY >= 175 && mouseY <= 225) {
    if (money >= cost) {
      if (huts * 5 > auto) {
        money -= cost
        auto += 1
        cost += auto
      }
    }
  }
  if (mouseX >= 175 && mouseX <= 225 &&
    mouseY >= 325 && mouseY <= 375) {
    if (money >= cost2) {
      money -= cost2
      power1 += 1
      cost2 *= power1
    }
  }
  if (mouseX >= 325 && mouseX <= 375 &&
    mouseY >= 325 && mouseY <= 375) {
    if (money >= cost3) {
      money -= cost3
      huts += 1
      cost3 += huts*100
    }
  }
  
}


function draw() {
  background(220);
  text("$" + money, 10, 15);
  text("$" + auto * power1 + " per second", 10, 30);
  rect(175, 175, 50, 50);
  text("FARM", 183, 205);
  rect(325, 175, 50, 50);
  text("SLAVE", 333, 200);
  text("$" + cost, 333, 210);
  rect(20, 175, 50, 50);
  text("FARM", 23, 190);
  text("POWER", 23, 200);
  text("$" + cost1, 23, 210);
  text(auto + " slaves", 10, 45);
  text(huts*5+" rooms",10,60);
  text(power + " farming power", 10, 75);
  text(power1 + " slave power", 10, 90);
  rect(175, 325, 50, 50);
  text("SLAVE", 180, 340);
  text("POWER", 180, 350);
  text("$" + cost2, 180, 360);
  text(achievements+"/9 achievements", 10, 120);
  text(mouseX+", "+mouseY,10,135);
  text(month+"/"+day+"/"+year,10,105);
  rect(325,325,50,50);
  text("HUT",338,345);
  text("$"+cost3,338,360);
  text(dialogue,0,275);
  

  millisecond += 1
  if (millisecond >= 50) {
    second += 1
    money += auto * power1
    millisecond = 0
    timer += 1
  }
  
  if (second >= 1) {
    day += 1
    second = 0
  }
  if (day >= 32) {
    month += 1
    day = 1
  }
  if (month >= 13) {
    year += 1
    month = 1
  }
  if (clicks >= 100) {
    dialogue = "ACHIEVEMENT GET: 100 Clicks - Fast Hand!"
    achievements += 1
  }
  
  if (auto >= 100) {
    dialogue = "ACHIEVEMENT GET: 100 Slaves - Entrepreneur!"
    achievements += 1
  }
  
  if (money >= 100000) {
    dialogue = "ACHIEVEMENT GET: $100000 - Rich!"
    achievements += 1
  }
     
  if (huts*5 >= 100) {
    dialogue = "ACHIEVEMENT GET: 100 Rooms - Hillbilly Hotel"
    achievements += 1
  }
  
  if (power1 >= 5) {
    dialogue = "ACHIEVEMENT GET: 5 Slave Power - Whip & Nae Nae"
    achievements += 1
  }
  
  if (power >= 100) {
    dialogue = "ACHIEVEMENT GET: 100 Farm Power - Lettuce Turnip The Beet!"
    achievements += 1
  }
  
  if (auto*power1 >= 1000) {
    dialogue = "ACHIEVEMENT GET: $1000 Per Sec - It's Growing On Trees!"
    achievements += 1
  }
  
  if (clicks >= 1000) {
    dialogue = "ACHIEVEMENT GET: 1000 Clicks - Addicted!"
    achievements += 1
  }
  
  if (mouseX == 69 && mouseY == 69) {
    dialogue = "ACHIEVEMENT GET: Mouse Coordinates 69,69 - Nice."
    achievements += 1
  }
}