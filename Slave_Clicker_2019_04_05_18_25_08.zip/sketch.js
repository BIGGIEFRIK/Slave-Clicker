function setup() {
  createCanvas(400, 400);
  money = 0
  auto = 0
  cost = 10
  cost1 = 8
  cost2 = 20
  power = 1
  power1 = 1
  millisecond = 0
}

mouseClicked = function() {
    if (mouseX >= 20 && mouseX <= 175 &&
        mouseY >= 175 && mouseY <= 225) {
        if (money >= cost1) {
          money -= cost1
          power += 1
          cost1 += power
        }
    }
  
    if (mouseX >= 175 && mouseX <= 225 &&
        mouseY >= 175 && mouseY <= 225) {
        money += power
    }
  
    if (mouseX >= 325 && mouseX <= 375 &&
        mouseY >= 175 && mouseY <= 225) {
        if (money >= cost) {
          money -= cost
          auto += 1
          cost += auto
        }
    
    }
    if (mouseX >= 175 && mouseX <= 225 &&
        mouseY >= 325 && mouseY <= 375) {
        if (money >= cost2) {
          money -= cost2
          power1 += 1
          cost2 *= power1
        }
    
    }
}

function draw() {
  background(220);
  text("$"+money,10,15);
  text("$"+auto*power1+" per second", 10, 30);
  rect(175,175,50,50);
  text("FARM",183,205);
  rect(325,175,50,50);
  text("SLAVE",333,200);
  text("$"+cost,333,210);
  rect(20,175,50,50);
  text("FARM",23,190);
  text("POWER",23,200);
  text("$"+cost1,23,210);
  text(auto+" slaves",10,45);
  text(power+" farming power",10,60);
  text(power1+" slave power",10,75);
  rect(175,325,50,50);
  text("SLAVE",180,340);
  text("POWER",180,350);
  text("$"+cost2,180,360);
  text(mouseX+", "+mouseY,10,100);
  
  millisecond += 1
  if (millisecond >= 50) {
    money += auto * power1
    millisecond = 0
  }
}
